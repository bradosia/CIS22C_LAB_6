/*
Branden Lee
CIS 22C
Fall 2017
Lab 6

Used Microsoft Visual Studio 2017
Windows SDK Version: 10.0.16299.0
Use SDK Version: 10.0.15063.0 for De Anza Computers
USE DOXYGEN COMPLIANT DOCUMENTATION
*/

#ifndef MATH_HELPER_H
#define MATH_HELPER_H

/**
@class MathHelper
A collection of static mathematic methods
*/
class MathHelper
{
public:
	static int max (int x, int y);
};
#endif